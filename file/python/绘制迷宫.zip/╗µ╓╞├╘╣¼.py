import pygame
import sys
from pygame.locals import * # pygame
import random


# 以下我看不懂————————————————————————————————————————
class Maze:
    def __init__(self, width, height):
        self.width = width
        self.height = height
        self.map = [[1 if x % 2 == 1 and y % 2 == 1 else 0 for x in range(width)] for y in range(height)]
        self.map[1][0] = 1  # 入口
        self.map[height - 2][width - 1] = 3 # 出口
        self.visited = []
        # right up left down
        self.dx = [1, 0, -1, 0]
        self.dy = [0, -1, 0, 1]

    def set_value(self, point, value):
        self.map[point[1]][point[0]] = value

    def get_value(self, point):
        return self.map[point[1]][point[0]]


    def get_neighbor(self, x, y, value):
        res = []
        for i in range(4):
            if 0 < x + self.dx[i] < self.width - 1 and 0 < y + self.dy[i] < self.height - 1 and \
                    self.get_value([x + self.dx[i], y + self.dy[i]]) == value:
                res.append([x + self.dx[i], y + self.dy[i]])
        return res


    def get_neighbor_wall(self, point):
        return self.get_neighbor(point[0], point[1], 0)


    def get_neighbor_road(self, point):
        return self.get_neighbor(point[0], point[1], 1)

    def deal_with_not_visited(self, point, wall_position, wall_list):
        if not [point[0], point[1]] in self.visited:
            self.set_value(wall_position, 1)
            self.visited.append(point)
            wall_list += self.get_neighbor_wall(point)

    def generate(self):
        start = [1, 1]
        self.visited.append(start)
        wall_list = self.get_neighbor_wall(start)
        while wall_list:
            wall_position = random.choice(wall_list)
            neighbor_road = self.get_neighbor_road(wall_position)
            wall_list.remove(wall_position)
            self.deal_with_not_visited(neighbor_road[0], wall_position, wall_list)
            self.deal_with_not_visited(neighbor_road[1], wall_position, wall_list)

    def is_out_of_index(self, x, y):
        return x == 0 or x == self.width - 1 or y == 0 or y == self.height - 1

    def dfs(self, x, y, path, visited=[]):

        if self.is_out_of_index(x, y):
            return False

        if [x, y] in visited or self.get_value([x, y]) == 0:
            return False

        visited.append([x, y])
        path.append([x, y])

        if x == self.width - 2 and y == self.height - 2:
            return True

        for i in range(4):
            if 0 < x + self.dx[i] < self.width - 1 and 0 < y + self.dy[i] < self.height - 1 and \
                    self.get_value([x + self.dx[i], y + self.dy[i]]) == 1:
                if self.dfs(x + self.dx[i], y + self.dy[i], path, visited):
                    return True
                elif not self.is_out_of_index(x, y) and path[-1] != [x, y]:
                    path.append([x, y])

    def dfs_route(self):
        path = []
        self.dfs(1, 1, path)

        ans = [[0, 1]]
        for i in range(len(path)):
            ans.append(path[i])
            if 0 < i < len(path) - 1 and path[i - 1] == path[i + 1]:
                ans.append(path[i])
        ans.append([width - 1, height - 2])
        return ans

    def bfs_route(self):
        start = {'x': 0, 'y': 1, 'prev': None}
        now = start
        q = [start]
        visited = [[start['x'], start['y']]]
        while q:
            now = q.pop(0)
            # 结束
            if now['x'] == self.width - 2 and now['y'] == self.height - 2:
                break
            roads = my_maze.get_neighbor_road([now['x'], now['y']])
            for road in roads:
                if not road in visited:
                    visited.append(road)
                    q.append({'x': road[0], 'y': road[1], 'prev': now})

        ans = []
        while now:
            ans.insert(0, [now['x'], now['y']])
            now = now['prev']
        ans.append([width - 1, height - 2])
        return ans

# 以上我看不懂——————————————————————————————————————————————

# 定义基础变量
map = []
size_maze=0
gameMode = 0
score = 0
WITHE = (220, 220, 220)
RED = (219, 112, 147)
BLACK = (105, 105, 105)
BlUE = (138, 43, 226)
SNOW = (250, 255, 255)
humanY, humanX = 0, 0

# 初始化——————————————————————————————————————————————
pygame.init()
def gameStrat(size = 11):
    global size_maze
    global map
    global humanX, humanY
    global score
    map = []
    humanX, humanY = 1, 0
    size_maze = size + score
    my_map = Maze(size_maze, size_maze)
    my_map.generate()
    i = 0
    while i < size_maze:
        j = 0
        map.append([])
        while j < size_maze:
            map[i].append(my_map.get_value([i,j]))
            j+=1
        i += 1
    map[humanY][humanX] = 2

gameStrat()
# 初始化游戏

# 定义基础属性
size = width, height = (size_maze) * 20, (size_maze) * 20
screen = pygame.display.set_mode(size, RESIZABLE, 32)
pygame.display.set_caption('迷宫')
clock = pygame.time.Clock()
pygame.key.set_repeat(35, 35)


# 人物移动
def humanMove(p):
    global humanY, humanX
    if p == 'left':
        if humanX - 1 >= 0 and (map[humanY][humanX - 1] == 1 or map[humanY][humanX - 1] == 3):
            map[humanY][humanX] = 1
            humanX = humanX - 1
            map[humanY][humanX] = 2
    if p == 'right':
        if humanX + 1 < len(map[humanY]) and (map[humanY][humanX + 1] == 1 or map[humanY][humanX + 1] == 3):
            map[humanY][humanX] = 1
            humanX = humanX + 1
            map[humanY][humanX] = 2
    if p == 'up':
        if humanY - 1 >= 0 and (map[humanY - 1][humanX] == 1 or map[humanY - 1][humanX] == 3):
            map[humanY][humanX] = 1
            humanY = humanY - 1
            map[humanY][humanX] = 2
    if p == 'down':
        if humanY + 1 < len(map) and (map[humanY + 1][humanX] == 1 or map[humanY + 1][humanX] == 3):
                map[humanY][humanX] = 1
                humanY = humanY + 1
                map[humanY][humanX] = 2

# 游戏部分
while True:


# 按键事件
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()
        if event.type == KEYDOWN:
            if gameMode == 1:
                if event.key == K_LEFT:
                    humanMove('left')
                if event.key == K_RIGHT:
                    humanMove('right')
                if event.key == K_DOWN:
                    humanMove('down')
                if event.key == K_UP:
                    humanMove('up')
                if event.key == K_DELETE:
                    gameStrat()
            else:
                if event.key == K_RETURN:
                    gameMode = 1

    h = 0
    w = 0
    # 遍历数组
    if gameMode == 1:
        screen.fill(WITHE)
        for i in range(0, len(map)):
            for j in range(0, len(map[0])):

                # 绘制游戏
                if map[i][j] == 0:
                    pygame.draw.rect(screen, BLACK, (w, h, 20, 20), 0)
                elif map[i][j] == 2:
                    pygame.draw.circle(screen, RED, (w +10, h + 10), 10 , 0)
                    humanY, humanX = i, j
                    if humanY == (len(map) - 1) and humanX == (len(map[0]) - 2):
                        gameMode = 0
                        score += 2
                        gameStrat()
                        size = width, height = (size_maze) * 20, (size_maze) * 20
                        screen = pygame.display.set_mode(size, RESIZABLE, 32)
                elif map[i][j] == 3:
                    p = [(w + 2, h + 2), (w + 10, h + 18), (w + 18, h + 2)]
                    pygame.draw.polygon(screen, BlUE, p, 0)
                else:
                    pygame.draw.rect(screen, WITHE, (w, h, 20, 20), 0)
                w = w + 20
            w = 0
            h = h + 20
    else:
        # 绘制计分板
        screen.fill(SNOW)
        font = pygame.font.Font('./font/a.ttf', size_maze)
        textSurface = font.render('Please press enter to start the game', True, (255, 200, 255))
        t_sc = font.render('Your score:{}'.format(score), True, (255, 200, 255))
        screen.blit(textSurface, (int(width / 20), int((height / 2) - (height / 7))))
        screen.blit(t_sc, (int((width / 2) - (width / 6)), int(height / 2)))

    pygame.display.flip()
    clock.tick(60)
