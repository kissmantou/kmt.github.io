import os
import cv2
import time
import random


shibaicishu = 0

def start(position):
    global shibaicishu
    tiaozhan = cv2.imread("./image/tiaozhan.png")
    jiesuan = cv2.imread("./image/jiesuan.png")
    shibai = cv2.imread("./image/shibai.png")
    while True:
        os.system('adb shell screencap -p /sdcard/omoji.png')
        os.popen('adb pull /sdcard/omoji.png')

        time.sleep(1.5)

        omoji = cv2.imread("./omoji.png")

        kaishi = matchImage(tiaozhan, omoji)
        jieshu = matchImage(jiesuan, omoji)
        chongkai = matchImage(shibai, omoji)





        if(kaishi != None and kaishi != 0):
            os.system('adb shell input tap {} {}'.format(kaishi[0] + position[0], kaishi[1] + position[1]))
            print('点击了',kaishi[0] + position[0], kaishi[1] + position[1])
            time.sleep(2)

        if(chongkai != None and chongkai != 0):
            if(shibaicishu < 3):
                os.system('adb shell input tap {} {}'.format(chongkai[0] + position[4], chongkai[1] + position[5]))
                shibaicishu += 1
                print('挑战失败正在重开，失败次数：',shibaicishu)

            else:
                print('失败次数过多，已停止')
                return 1, shibaicishu;

            time.sleep(1)

        if (jieshu != None and jieshu != 0):
            os.system('adb shell input tap {} {}'.format(jieshu[0] + position[2], jieshu[1] + position[3]))
            print('点击了', jieshu[0] + position[2], jieshu[1] + position[3])
            time.sleep(2)
            shibaicishu = 0
            return 1 ,shibaicishu;



def Positionramdom():
    numx = []
    n = 0
    while n < 6:
        numx.append(random.uniform(0, 120))
        n += 1
    return numx

def matchImage(target, template,threshold = 0.01):

    if (target.all() == None or template.all() == None):
        print("图片数据有误")
        return None
    if (threshold >= 1 or threshold <= 0):
        print("阈值设置有误")
        return 0

    result = cv2.matchTemplate(target,template,cv2.TM_SQDIFF_NORMED)

    min_val, max_val, min_loc, max_loc = cv2.minMaxLoc(result)

    if (min_val >=threshold):

        return 0
    return min_loc





if __name__ == '__main__':
    print('选择链接模式输入1为有线,任意输入无线')
    modn  = input()
    if modn == '1':
        print('已选择有线模式，请链接usb线')
    else:
        print('请保证手机和电脑在同一wifi下')
        print('曾经连接过输入1，没连接过请随意输入')
        modx = input()
        if modx != '1':
            print('请先连接usb线链接完成随意输入')
            x = input()
            os.system('adb tcpip 5555')
            print('请拔出usb线后输入手机ip地址')
            x = input()
            os.system('adb connect {}'.format(x))
            print('完成，若没反应请关闭应用重新连接无线模式')


    while True:
        i = 0
        print("请输入你想刷的御魂次数")
        n = input()
        shibai = 0
        while i < int(n) and shibai < 3:
            cishu, shibai = start(Positionramdom())
            i += cishu
            print("你刷了", i, "次御魂")

