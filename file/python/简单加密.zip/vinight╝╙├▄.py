
def jm(s, k, boo):
    if boo:
        s0 = list(reversed([chr(ord(x)+int(k)) for x in s]))
    else:
        s0 = list(reversed([chr(ord(x)-int(k)) for x in s]))
    s1 = ""
    for i in s0:
        s1 = s1 + i
    return s1


string = jm('this is test string 这是一条测试字符串', 123, True)

print(string)
print(jm(string, 123, False))
