import java.util.*;
import java.util.regex.*;

class TestString
{
	private String yb;
	private String wb;
	private List<String> strarr=new ArrayList<String>();
	private List<Integer> intarr=new ArrayList<Integer>();
	TestString(String yb,String wb){
		this.yb=yb;
		this.wb=wb;
	}
	private void yunsuan(){
		Pattern re=Pattern.compile("\\S");
		Matcher txt=re.matcher(yb);
		Matcher txt2=re.matcher(wb);
		strarr.clear();
		intarr.clear();
		for(int i=0;i<wb.length();i++){
			txt.find();
			txt2.find();
			if(!txt.group().equals(txt2.group())){
				strarr.add(txt2.group());
				intarr.add(i+1);
			}
		}
	}
	public List getIntArray(){
		yunsuan();
		return intarr;
	}
	public List getStringArray(){
		yunsuan();
		return strarr;
	}
}
