package com.youshang.jisuanqi;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.graphics.Color;
import android.content.Intent;
import com.youshang.jisuanqi.activity2;
public class MainActivity extends Activity 
{
	Button 加,减,乘,除,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,ac,d,d1,d2,top1,top2,top3,sc;
	TextView txt,计算面板,wh;
	ImageView img;
	String fh="";
	String fhst="_";
	String 第一个数="０";
	String 第二个数="０";
	String 符号存在="否";
	Double i1,i2;
	long i3,i4;
	String 运算方法="普通";

	activity2 act2=new activity2();
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.main);
		加=(Button)findViewById(R.id.加);
		减=(Button)findViewById(R.id.减);
		乘=(Button)findViewById(R.id.乘);
		除=(Button)findViewById(R.id.除);
		txt=(TextView)findViewById(R.id.txt);
		wh=(TextView)findViewById(R.id.wh);
		计算面板=(TextView)findViewById(R.id.计算面板);
		img=(ImageView)findViewById(R.id.img);
		b0=(Button)findViewById(R.id.b0);
		b1=(Button)findViewById(R.id.b1);
		b2=(Button)findViewById(R.id.b2);
		b3=(Button)findViewById(R.id.b3);
		b4=(Button)findViewById(R.id.b4);
		b5=(Button)findViewById(R.id.b5);
		b6=(Button)findViewById(R.id.b6);
		b7=(Button)findViewById(R.id.b7);
		b8=(Button)findViewById(R.id.b8);
		b9=(Button)findViewById(R.id.b9);
		ac=(Button)findViewById(R.id.ac);
		d=(Button)findViewById(R.id.d);
		d1=(Button)findViewById(R.id.d1);
		d2=(Button)findViewById(R.id.d2);
		top1=(Button)findViewById(R.id.top1);
		top2=(Button)findViewById(R.id.top2);
		top3=(Button)findViewById(R.id.top3);
		sc=(Button)findViewById(R.id.sc);
		d.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					if(符号存在=="否"){
						第一个数=第一个数+".";
						计算面板.setText(第一个数+"\n―――\n"+第二个数);
					}
					if(符号存在=="是"){
						第二个数=第二个数+".";
						计算面板.setText(第一个数+"\n―――\n"+第二个数);
					}
				}
			});
			
		sc.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					del();print("删除");
				}});
		
			
		
		top1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					
					print("模式1");
					moshi(1);
				}});
				
				
	 wh.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					print("问号");
					Intent i=new Intent(MainActivity.this,activity2.class);
					startActivity(i);
				}});
			
		top2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					moshi(2);print("模式2");
				}});
				
		top3.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					moshi(3);print("模式3");
				}});
		
		
		
		
		ac.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					print("归零");
					计算面板.setText("０\n―――\n０");
					txt.setText("运算符号为:_");
					第一个数="０";
					第二个数="０";
					符号存在="否";
				}});
		
		img.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
		print("退出");
	finish();

				}});
		
		加.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					JJCC("加");print("加");
				}});
				
		减.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					JJCC("减");print("减");
				}});
				
		乘.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					JJCC("乘");print("乘");
				}});
				
				
		除.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					JJCC("除");print("除");
				}});
				
		b0.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("0");print("0");
				}});
				
				
		b1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				pushInt("1");print("1");
				}});
		b2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("2");print("2");
				}});
		b3.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("3");print("3");
				}});
				
		b4.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("4");print("4");
				}});
		b5.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("5");print("5");
				}});
		b6.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("6");print("6");
				}});
		b7.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("7");print("7");
				}});
		b8.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("8");print("8");
				}});
		b9.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					pushInt("9");print("9");
				}});
				
				
		d1.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					等于();print("等于");
				}});
				
		d2.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
					等于();print("等于");
				}});
		
				}
        

	public void print(String str){
		Toast.makeText(this,str,0).show();
	}
				
	public void 等于(){
		try{
			
     i1=Double.parseDouble(第一个数.replace("０",""));
			i2=Double.parseDouble(第二个数.replace("０",""));
			i3=(int)Double.parseDouble(第一个数.replace("０",""));
			i4=(int)Double.parseDouble(第二个数.replace("０",""));
	 if(运算方法=="科学"){
	 符号存在="是";
		if(第一个数=="０"||第二个数=="０"){
			print("请输入数值");
		}
		else{
		switch(fh){
			case "加":
				计算面板.setText((i1+i2)+"\n―――\n"+"０");
				String str=Double.toString(i1+i2);
				第一个数=str;
				第二个数="０";
				break;
			case "减":
				计算面板.setText((i1-i2)+"\n―――\n"+"０");
				String str1=Double.toString(i1-i2);
				第一个数=str1;
				第二个数="０";
				break;
			case "乘":
				计算面板.setText((i1*i2)+"\n―――\n"+"０");
				String str2=Double.toString(i1*i2);
				第一个数=str2;
				第二个数="０";
				break;
			case "除":
				计算面板.setText((i1/i2)+"\n―――\n"+"０");
				String str3=Double.toString(i1/i2);
				第一个数=str3;
				第二个数="０";
				break;
				}
		}}
		else if(运算方法=="普通"){
			符号存在="是";
			if(第一个数=="0"||第二个数=="0"){
				print("请输入数值");
			}
			else{
				switch(fh){
					case "加":
						计算面板.setText((i3+i4)+"\n―――\n"+"０");
						String str=Long.toString(i3+i4);
						第一个数=str;
						第二个数="０";
						break;
					case "减":
						计算面板.setText((i3-i4)+"\n―――\n"+"０");
						String str1=Long.toString(i3-i4);
						第一个数=str1;
						第二个数="０";
						break;
					case "乘":
						计算面板.setText((i3*i4)+"\n―――\n"+"０");
						String str2=Long.toString(i3*i4);
						第一个数=str2;
						第二个数="０";
						break;
					case "除":
						计算面板.setText((i3/i4)+"\n―――\n"+"０");
						String str3=Long.toString(i3/i4);
						第一个数=str3;
						第二个数="０";
						break;
				} 
			}
			
		}
		}catch(Exception e){}}
		
		public void moshi(int a){
			switch(a){
				case 1:
					top1.setBackgroundColor(Color.parseColor("#C0C0C0"));top2.setBackgroundColor(Color.parseColor("#9F9F9F"));top3.setBackgroundColor(Color.parseColor("#9F9F9F"));
					运算方法="普通";
					break;
				case 2:
					top2.setBackgroundColor(Color.parseColor("#C0C0C0"));top3.setBackgroundColor(Color.parseColor("#9F9F9F"));top1.setBackgroundColor(Color.parseColor("#9F9F9F"));
					运算方法="科学";
					break;
				case 3:
					top3.setBackgroundColor(Color.parseColor("#C0C0C0"));top1.setBackgroundColor(Color.parseColor("#9F9F9F"));top2.setBackgroundColor(Color.parseColor("#9F9F9F"));
					运算方法="汇率";
					break;
			}
			print("运算方法为:"+运算方法+"方法。");
		}
		
		public void pushInt(String STR){
			if(符号存在=="否"){
				第一个数=(第一个数+STR).replace("０","");
				计算面板.setText(第一个数+"\n―――\n"+第二个数);
			}
			if(符号存在=="是"){
				第二个数=(第二个数+STR).replace("０","");
				计算面板.setText(第一个数+"\n―――\n"+第二个数);
			}
		
		}
		
		int skdjd=0;
		
		
		
		
		
		
		public void JJCC(String STR){
			
			if(第一个数=="０"){
			
			}
			else{
			if(符号存在=="否"){
				符号存在="是";
				fh=STR;
				}else{
					等于();
					fh=STR;
					}
					
					switch(STR){
						case "加":
							fhst="+";
							break;
							case "减":
								fhst="-";
								break;
								case "乘":
									fhst="×";
									break;
									case "除":
										fhst="÷";
										break;
					}
			txt.setText("运算符号为:"+fhst);
		}
		}
		public void del(){
			if(符号存在=="否"){
				if(第一个数=="０"){print("无需删除");}
				else{
					if(第一个数.length()==1){
						第一个数="０";
						计算面板.setText(第一个数+"\n―――\n０");
					}
					else{
					第一个数=第一个数.substring(0,第一个数.length()-1);}
					计算面板.setText(第一个数+"\n―――\n０");
					}
			}
			else{
				if(第二个数=="０"){print("无需删除");}
				else{
					if(第二个数.length()==1){
            第二个数="0";		
						计算面板.setText(第一个数+"\n―――\n"+第二个数);
					}
					else{
						第二个数=第二个数.substring(0,第二个数.length()-1);}
						计算面板.setText(第一个数+"\n―――\n"+第二个数);
					}
				}
			}
		
		
		
	 }
