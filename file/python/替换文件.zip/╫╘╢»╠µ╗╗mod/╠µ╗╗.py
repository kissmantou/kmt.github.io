from tkinter import *
from tkinter import  messagebox
import re
import shutil

root = Tk()
root.geometry('400x100+800+500')
root.title('作者:QQ1121169088')

class Application(Frame):  # 定义一个叫application的类，继承父类frame
    path = StringVar()
    choose = StringVar()

    def __init__(self, master=None):   # master就是传入的root，用super把root传入父类frame
        super().__init__(master)
        self.master = master
        self.pack()
        self.creatWidget()

    def creatWidget(self):

        self.labe1 = Label(self, text='请输入游戏路径')
        self.labe1.pack()

        # StringVar变量保存到指定组件。
        # 组件内容和StringVar值随着互相变化

        self.entry1 = Entry(self, textvariable=self.path)
        self.entry1.pack()
        if getdata() != None:
            self.path.set(getdata())

        self.choose.set(True)

        self.radio1 = Radiobutton(self, text='添加', value='add', variable=self.choose).pack(side='left')
        self.radio1 = Radiobutton(self, text='取消', value='de', variable=self.choose).pack(side='left')

        self.btn = Button(self, text='ok', command=self.click)
        self.btn.pack(side='left')

    def click(self):
        self.ABS_path = self.path.get()+'\DW\Data3.pak'
        try:
            # try保证无异常，shutil为移动文件
            if self.choose.get() == 'add':
                shutil.copyfile('./data/moddata/Data3.pak', self.ABS_path)
                messagebox.showinfo('test', '安装成功')
            elif self.choose.get() == 'de':
                shutil.copyfile('./data/re/Data3.pak', self.ABS_path)
                messagebox.showinfo('test', '卸载成功')
        except:
            messagebox.showinfo('test', '错误！请检查路径或文件是否损坏')

        setdata(self.path.get())


def getdata():
    file = open('./data/data.txt', 'r', encoding='utf-8').readline()
    if file != '':
        return file
    else:
        return None

def setdata(data):
    file = 'data/data.txt'
    with open(file, 'w') as f:
        f.write(data)

app = Application(master=root)  # 传入的参数是root也就是父窗口
root.mainloop()