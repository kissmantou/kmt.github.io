package com.youshang.jisuanqi;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
public class activity2 extends Activity
{
Button p,k,h,j;
ImageButton fns;
LinearLayout l1,l2,l3,l4;
int 页面=1;
	@Override
	public void onCreate(Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onCreate(savedInstanceState);
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.huilv);
		p=(Button)findViewById(R.id.p);
		k=(Button)findViewById(R.id.k);
		h=(Button)findViewById(R.id.h);
		j=(Button)findViewById(R.id.j);
		fns=(ImageButton)findViewById(R.id.fns);
		l1=(LinearLayout)findViewById(R.id.l1);
		l2=(LinearLayout)findViewById(R.id.l2);
		l3=(LinearLayout)findViewById(R.id.l3);
		l4=(LinearLayout)findViewById(R.id.l4);
		//Gone the views
		l2.setVisibility(View.GONE);
		l3.setVisibility(View.GONE);
		l4.setVisibility(View.GONE);
		
		
		fns.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
				finish();
				}
			});
		
		
		p.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
		if(页面==2||页面==3||页面==4){
		
			l4.setVisibility(View.GONE);
			l3.setVisibility(View.GONE);
		l2.setVisibility(View.GONE);
			l1.setVisibility(View.VISIBLE);
			py(0,1500,0,0,l4);
			py(0,1500,0,0,l3);
			py(0,1500,0,0,l2);
		}
		页面=1;
				}
			});
		
		k.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
if(页面==1){
	py(1500,0,0,0,l2);
	l2.setVisibility(View.VISIBLE);
}
else if(页面==3||页面==4){
	py(0,1500,0,0,l3);
	py(0,1500,0,0,l4);
	l4.setVisibility(View.GONE);
	l3.setVisibility(View.GONE);
	l2.setVisibility(View.VISIBLE);
}
		
		页面=2;
				}
			});
		
		h.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
if(页面==1||页面==2){
	py(1500,0,0,0,l3);
	l3.setVisibility(View.VISIBLE);
}
else if(页面==4){
	py(0,1500,0,0,l4);
	l4.setVisibility(View.GONE);
	l3.setVisibility(View.VISIBLE);
}
					
					页面=3;
				}
			});
		
		j.setOnClickListener(new OnClickListener(){
				@Override
				public void onClick(View p1)
				{
if(页面==3||页面==2||页面==1){
	py(1500,0,0,0,l4);
l4.setVisibility(View.VISIBLE);
}
					
					页面=4;
				}
			});
		
		
		
		
 }
	public void py(int a,int b,int c,int d,View e){
		final Animation translateAnimation=new TranslateAnimation(a,b,c,d);
		translateAnimation.setDuration(400);
		translateAnimation.setInterpolator(this,android.R.anim.accelerate_decelerate_interpolator);
		translateAnimation.setFillAfter(false);
		e.startAnimation(translateAnimation);
	}
	
	
	
}
